#!/bin/sh

NS="1024 2048 4096 "

PROCS="2 4 8 16"

RESULTDIR=result_weak/
