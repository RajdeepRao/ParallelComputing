#!/bin/sh

./polynomial 1000000000 1
./polynomial 1000000000 10
./polynomial 1000000000 100
./polynomial 1000000000 1000

