#!/bin/sh

./polynomial_gpu 1000000000 1
./polynomial_gpu 1000000000 10
./polynomial_gpu 1000000000 100
./polynomial_gpu 1000000000 1000

